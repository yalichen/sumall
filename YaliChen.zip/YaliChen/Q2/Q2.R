setwd("/Users/yc2833/Downloads")
# install.packages("rjson")
# install.packages("stringr")
# install.packages("data.table")

require(rjson)
require(stringr)
require(data.table)

# Import Data
tweets_json<-readLines("tweets.json")
length(tweets_json)

# Parse Data using packages rjson
tweets<-lapply(tweets_json,function(x) fromJSON(x)$created_at)
tweets<-unlist(tweets)
# write.csv(tweets,"tweets_date.csv",row.names=FALSE)

# Convert to data.table
tweets.dt<-data.table(data.frame(tweets,stringsAsFactors=FALSE))
head(tweets.dt)

# Split the date
ll<-unlist(strsplit(tweets.dt$tweets," ",fixed=TRUE))
head(ll,12)
ind<-seq(1,length(ll),by=6)
tweets.dt[,weekday:=ll[ind]]
tweets.dt[,month:=ll[ind+1]]
tweets.dt[,date:=ll[ind+2]]
tweets.dt[,time:=ll[ind+3]]
tweets.dt[,tz:=ll[ind+4]]
tweets.dt[,year:=ll[ind+5]]

tweets.dt[,year_month_date:=as.Date(paste(year,month,date),"%Y %b %d")]
tweets.dt[,count:=1L]
setkey(tweets.dt,year_month_date)

tweets.dt.count<-tweets.dt[,.SD[,sum(count)],by=year_month_date]

write.csv(tweets.dt.count,"tweets_dt_count.csv",row.names=FALSE)

## Data for Oct 09 and Oct 10 are missing
missing<-data.frame(date=c("2013-10-09","2013-10-10"),count=c(0,0))
tweets.dt.count.whole<-rbind(tweets.dt.count[1:47,],missing,tweets.dt.count[48:52,])

write.csv(tweets.dt.count.whole,"tweets_dt_count_whole.csv",row.names=FALSE)
write.csv(tweets.dt,"tweets_dt.csv",row.names=FALSE)


########################## Join with other GDELT dataset ##########################
library(utils)
download.file("http://pastebin.com/raw.php?i=LrQhuVEZ", "Reading.GDELT.R")
source("Reading.GDELT.R")
file.remove("Reading.GDELT.R")


syria.df<-acquire.gdelt.daily(start.date=20130823, end.date=20131015, country.code="SY")
syria.df<-cbind(syria.df, assign.CAMEO(syria.df))

setwd("/Users/yalichen/Dropbox/sumall-master/data")
syria<-read.csv("syria_df.csv",header=TRUE,stringsAsFactors=FALSE)
dim(syria)
names(syria)
syria[1:5,1:5]
syria_num_mention_all<-aggregate(cbind(NumMentions,NumSources,NumArticles)~SQLDATE,syria,sum)
syria_goldsteinscale_all<-aggregate(GoldsteinScale~SQLDATE+ActionGeo_ADM1Code,syria,mean)

head(syria_num_mention_all)
head(syria_goldsteinscale_all)

dim(syria_num_mention_all)
dim(syria_goldsteinscale_all)

ind.1<-which(syria_num_mention_all$SQLDATE>=20130823)
ind.2<-which(syria_goldsteinscale_all$SQLDATE>=20130823)


syria_num_mention<-syria_num_mention_all[ind.1,]
syria_goldsteinscale<-syria_goldsteinscale_all[ind.2,]


syria_goldsteinscale_sub<-syria_goldsteinscale[-1:-142,]
syria_goldsteinscale_sub$id<-as.numeric(gsub("[A-Za-z]{2}(\\d{2})","\\1",syria_goldsteinscale_sub[,2]))


write.csv(syria_num_mention,"syria_num_mention.csv",row.names=FALSE)
write.csv(syria_goldsteinscale_sub,"syria_goldsteinscale_sub.csv",row.names=FALSE)

data.viz<-cbind(tweets.dt.count.whole,syria_num_mention[,c(2,3,4)])
write.csv(data.viz,"data_viz.csv",row.names=FALSE)




