setwd("/Users/yalichen/Dropbox/sumall-master/data")
###### Packages
#install.packages("data.table")
#install.packages("stringr")
#install.packages("ggmap")

require(data.table)
require(stringr)
require(ggmap)

############ Import Data and Data Cleaning ############
train.names<-read.csv("train_names.csv",header=TRUE,stringsAsFactors=FALSE)
test.names<-read.csv("test_names.csv",header=TRUE,stringsAsFactors=FALSE)
dim(train.names)
dim(test.names)
names(train.names)
names(test.names)
head(train.names)
head(test.names)

# The first column in train and test sets are useless and will not affect the result, so I delete them.
train.names.sub<-train.names[,-1]
test.names.sub<-test.names[,-1]

# Check for duplicate entries and delete them
ind.train<-which(duplicated(train.names.sub))
ind.test<-which(duplicated(test.names.sub))
train.names.sub.1<-train.names.sub[-ind.train,]
test.names.sub.1<-test.names.sub[-ind.test,]

# Convert to data.table since data.table is fast
train.dt<-data.table(train.names.sub.1)
test.dt<-data.table(test.names.sub.1)

###### Step 1: Match the names in the testing set to the names in training set.
# Paste resp.lsn and resp.ftn to get the full name
train.dt[,full.name:=paste(resp.lsn,resp.mi,resp.ftn)]
test.dt[,full.name:=paste(resp.lsn,resp.mi,resp.ftn)]

# Set key
setkey(train.dt,full.name)
setkey(test.dt,full.name)

# Match
match.names<-merge(train.dt,test.dt)
nrow(match.names)# 29307

# Delete useless columns
match.names.sub<-match.names[,c(1,5,6,7,8),with=FALSE]
head(match.names.sub)

############ Step 2: Geocode the address for the matching names ############
# Paste resp.strt.no, resp.strt, resp.state to get the full address. I will ignore resp.apn here since resp.apn will not affect the result of geocoding.

# I used Google Geocoding API here. The limit of Google Geocoding API is 2500 per 24 hour per ip address.To save time and reduce workload, I extracted unique addresses from the matched entries and conducted geocoding for those unique addresses. Then I merge the address, lng, lat to the matched entries.

# Extract unique address
match.names.sub[,address:= paste(resp.strt.no,resp.strt,resp.state,sep=",")]

address.unique<-unique(match.names.sub[,address])
n.add<-length(address.unique)
b<-c(seq(1,n.add,by=2500),n.add+1)
address.unique.dt<-data.table(address.unique)
address.unique.dt[,row.ind:= 1:n.add]
setkey(address.unique.dt,row.ind)

# Split the unique address into 8 subsets and conduct geocoding
getLngLat<-function(i)
{
    ind.s<-b[i]
    ind.e<-b[i+1]-1
    address.unique.dt.limit<-address.unique.dt[.(ind.s:ind.e)]
    address.unique.dt.limit[,c("lng","lat"):=geocode(address.unique)]
}

address.unique.dt.limit.1<-getLngLat(1)
address.unique.dt.limit.2<-getLngLat(2)
address.unique.dt.limit.3<-getLngLat(3)
address.unique.dt.limit.4<-getLngLat(4)
address.unique.dt.limit.5<-getLngLat(5)
address.unique.dt.limit.6<-getLngLat(6)
address.unique.dt.limit.7<-getLngLat(7)
address.unique.dt.limit.8<-getLngLat(8)

# Merge the lng lat of unique addresses with all addresses and full.names
address.unique.all<-rbind(address.unique.dt.limit.1,address.unique.dt.limit.2,address.unique.dt.limit.3,address.unique.dt.limit.4,address.unique.dt.limit.5,address.unique.dt.limit.6,address.unique.dt.limit.7,address.unique.dt.limit.8)

match.names.sub.1<-match.names.sub[,c(1,6),with=FALSE]
address.unique.all.1<-address.unique.all[,c(2,3,4),with=FALSE]
setnames(address.unique.all.1,"address.unique","address")

setkey(match.names.sub.1,address)
setkey(address.unique.all.1,address)

match.lnglat<-merge(match.names.sub.1,address.unique.all.1)
write.csv(match.lnglat,"lnglat.csv",row.names=FALSE)

############ Step 2: Calculate Distances ############
# Here I define the distances between two points as the length of the chord between the two points. Both the points are of the form (Longitude, Latitude)

# SumAll.org
# lat:40.720903
# lng:-73.997996

SumAll<-c(-73.997996,40.720903)

distance.chord <- function(point1,point2)
{
    R <- 6371
    
    p1rad <- point1 * pi/180
    p2rad <- point2 * pi/180
    
    lat <- p1rad[2]
    lon <- p1rad[1]
    
    u1 <- c(cos(lat)*cos(lon), cos(lat)*sin(lon), sin(lat))
    
    lat <- p2rad[2]
    lon <- p2rad[1]
    
    u2 <- c(cos(lat)*cos(lon),cos(lat)*sin(lon),sin(lat))
    
    R*sqrt(sum((u1-u2)^2))
    
}

distance.lnglat<-rep(0,nrow(match.lnglat))
distance.lnglat<-apply(match.lnglat[,c(3,4)],1,function(x) distance.chord(c(x[1],x[2]),SumAll))

match.distance<-cbind(match.lnglat,distance.lnglat)
match.distance.nodu<-match.distance[-which(duplicated(match.distance)),]

ind.sort<-sort(match.distance.nodu$distance.lnglat,index.return=TRUE)$ix
top.10<-match.distance.nodu[ind.sort[1:10],]


















