setwd("/Users/yalichen/Dropbox/sumall-master/data")
# Packages
# install.packages("tm")
# install.packages("SnowballC")
# install.packages("stringr")

require(stringr)
require(tm)
require(SnowballC)


train.insult<-read.csv("train_insult.csv",header=TRUE,stringsAsFactors=FALSE)
test.insult<-read.csv("test_insult.csv",header=TRUE,stringsAsFactors=FALSE)
dim(train.insult)
dim(test.insult)
names(train.insult)
names(test.insult)
head(train.insult)
head(test.insult)

# EDA
table(train.insult$Insult) #balanced?

################## Features Generated from Variable Date ##################

# Convert date to number of dates
datetonumeric<-function(x)
{
    date<-gsub("(^\\d{8})(\\d{6})Z","\\1",x)
    date.numeric<-as.numeric(as.Date(date,"%Y%m%d"))
}

# Convert time to number of seconds
timetonumeric<-function(x)
{
    time<-gsub("(^\\d{8})(\\d{6})Z","\\2",x)
    hour<-as.numeric(gsub("^(\\d{2})(\\d{2})(\\d{2})$","\\1",time))
    min<-as.numeric(gsub("^(\\d{2})(\\d{2})(\\d{2})$","\\2",time))
    sec<-as.numeric(gsub("^(\\d{2})(\\d{2})(\\d{2})$","\\3",time))
    time.numeric<-hour*60*60+min*60+sec
}

train.insult$date<-sapply(train.insult$Date,function(x) datetonumeric(x))
train.insult$time<-sapply(train.insult$Date,function(x) timetonumeric(x))

test.insult$date<-sapply(test.insult$Date,function(x) datetonumeric(x))
test.insult$time<-sapply(test.insult$Date,function(x) timetonumeric(x))

# Check
head(train.insult$date)
head(train.insult$time)

head(test.insult$date)
head(test.insult$time)



# Convert date to Weekdays
datetoweekdays<-function(x)
{
    date<-gsub("(^\\d{8})(\\d{6})Z","\\1",x)
    weekday<-weekdays(as.Date(date,"%Y%m%d"))
}

train.insult$weekday<-sapply(train.insult$Date,function(x) datetoweekdays(x))
test.insult$weekday<-sapply(test.insult$Date,function(x) datetoweekdays(x))


head(train.insult$weekday)
head(test.insult$weekday)


################## Features Generated from Variable Comment ##################
###### Detect Patterns: @, url, html structure ######
# Delete html structures and convert all the text to lower case
pattern='\\\"|\\\\xa0|\\\\\\\\xa0|\\\\\\\\n|\\\\n|\\\\\\\\xe2|\\\\\\\\xc2|\\\\u201|\\\\xf6r|\\\\\\\\x80|\\\\\\\\x9c|\\\\\\\\x9d|\\\\\\\\x99|\\\\\\\\xb9|\\\\xb|\\\\xaf|\\\\xf|\\\\xa|\\\\u|\\\\xe|\\\\\\\\'
train.insult$Comment<-sapply(train.insult$Comment,function(x) tolower(str_replace_all(x,pattern," ")))
test.insult$Comment<-sapply(test.insult$Comment,function(x) tolower(str_replace_all(x,pattern," ")))


###### Detect Special Patterns ######
# Detect Pattern "..."
pattern.1='\\.{2,}'
train.insult$ellipses<-sapply(train.insult$Comment,function(x) grepl(pattern.1,x))
test.insult$ellipses<-sapply(test.insult$Comment,function(x) grepl(pattern.1,x))

# Detect Pattern "!!!"
pattern.2='!{2,}'
train.insult$exclamation<-sapply(train.insult$Comment,function(x) grepl(pattern.2,x))
test.insult$exclamation<-sapply(test.insult$Comment,function(x) grepl(pattern.2,x))

# Detect Pattern "???"
pattern.3='\\?{2,}'
train.insult$questionmark<-sapply(train.insult$Comment,function(x) grepl(pattern.3,x))
test.insult$questionmark<-sapply(test.insult$Comment,function(x) grepl(pattern.3,x))

# Detect Pattern "*" potential dirty words
pattern.4='\\*'
train.insult$starsign<-sapply(train.insult$Comment,function(x) grepl(pattern.4,x))
test.insult$starsign<-sapply(test.insult$Comment,function(x) grepl(pattern.4,x))

# Detect Pattern "()"
pattern.5='\\(.*\\)'
train.insult$parenthesis<-sapply(train.insult$Comment,function(x) grepl(pattern.5,x))
test.insult$parenthesis<-sapply(test.insult$Comment,function(x) grepl(pattern.5,x))


# Detect Pattern "@"
pattern.6='@'
train.insult$atsign<-sapply(train.insult$Comment,function(x) grepl(pattern.6,x))
test.insult$atsign<-sapply(test.insult$Comment,function(x) grepl(pattern.6,x))

# Detect Pattern url link
pattern.7='http://|https://'
train.insult$urllink<-sapply(train.insult$Comment,function(x) grepl(pattern.7,x))
test.insult$urllink<-sapply(test.insult$Comment,function(x) grepl(pattern.7,x))


# Detect Pattern relative to "you are|you're"
pattern.8="you are|you're|you sound like|you|\\su\\s"
train.insult$youare<-sapply(train.insult$Comment,function(x) grepl(pattern.8,x))
test.insult$youare<-sapply(test.insult$Comment,function(x) grepl(pattern.8,x))



########## Delete Punctuations and special  html structures ##########
pattern="@\\S+|http://\\S+|https://\\S+|\\.{1,}|!{1,}|\\?{1,}|\\(|\\)|,|_|'|-|\\+|~|;|:|\\^|\\$|/|\\{|\\}|=|<|>|&|\\[|\\]|#|%|^\\s\\*+\\s$"

train.insult$Comment<-sapply(train.insult$Comment,function(x) str_replace_all(x,pattern," "))
test.insult$Comment<-sapply(test.insult$Comment,function(x) str_replace_all(x,pattern," "))


# Text Mining
# Create a corpus for variable text
train.corp<-Corpus(VectorSource(train.insult$Comment))
test.corp<-Corpus(VectorSource(test.insult$Comment))
# Eliminating Extra Whitespace
train.corp<-tm_map(train.corp,stripWhitespace)
test.corp<-tm_map(test.corp,stripWhitespace)
# Convert to Lower Case
train.corp<-tm_map(train.corp,tolower)
test.corp<-tm_map(test.corp,tolower)
# Eliminating Numbers
train.corp<-tm_map(train.corp,removeNumbers)
test.corp<-tm_map(test.corp,removeNumbers)
# Remove Punctuation
# train.corp<-tm_map(train.corp,removePunctuation)
# test.corp<-tm_map(test.corp,removePunctuation)
# Remove Stopwords
# train.corp<-tm_map(train.corp,removeWords,stopwords("english"))
# test.corp<-tm_map(test.corp,removeWords,stopwords("english"))
# Stemming
# train.corp<-tm_map(train.corp,stemDocument,language="english")
# test.corp<-tm_map(test.corp,stemDocument,language="english")

# Check
inspect(train.corp[1:3])
inspect(test.corp[1:3])



######### Create Term-Document Matrics for the dictionary. This is the "tf" matrix
train.d<-DocumentTermMatrix(train.corp)
test.d<-DocumentTermMatrix(test.corp)

# Find terms whose frequency > 3
popular.term.train<-findFreqTerms(train.d,10) # just to test the code
length(popular.term.train) #
popular.term.test<-findFreqTerms(test.d,10) # just to test the code
length(popular.term.test) #

d.pop<-Dictionary(popular.term.train)

train.d<-DocumentTermMatrix(train.corp,list(dictionary=d.pop))
test.d<-DocumentTermMatrix(test.corp,list(dictionary=d.pop))


inspect(train.d[1:5,1:10])
inspect(test.d[1:5,1:10])
dim(train.d)
dim(test.d)
train.d.df<-as.data.frame(as.matrix(train.d)) # feature
test.d.df<-as.data.frame(as.matrix(test.d)) # feature




# Find Frequent Terms Who Appear at Least 5 times
install.packages("FSelector")
require(FSelector)

names(train.d.df)[1:10]
train.d.df.select<-cbind(train.insult$Insult,train.d.df)
names(train.d.df.select)[1]<-"Insult"
names(train.d.df.select)[1:10]
train.d.df.select[,1]<-as.factor(train.d.df.select[,1])

weights<-chi.squared(Insult~., train.d.df.select)
head(weights)
subset<-cutoff.k(weights,800)
ind<-unlist(lapply(subset,function(x) which(names(train.d.df)==x))) # subset's index in train.d.df.select

# features selected using chi.squared from the DocumentTermsMatrix
train.feature<-train.d.df[,ind]
test.feature<-test.d.df[,ind]


####### Create a Badwords Dictionary

# Badwords
badwords<-read.csv("badwords.csv",header=TRUE,stringsAsFactors=FALSE)
head(badwords)
badwords<-as.vector(badwords[,1])
length(badwords)
class(badwords)

d<-Dictionary(badwords)

######### Create Term-Document Matrics for the dictionary. This is the "tf" matrix
train.badwords<-DocumentTermMatrix(train.corp,list(dictionary=d))
test.badwords<-DocumentTermMatrix(test.corp,list(dictionary=d))
inspect(train.badwords[1:5,1:5])
inspect(test.badwords[1:5,1:5])
dim(train.badwords)
dim(test.badwords)
train.badwords.df<-as.data.frame(as.matrix(train.badwords))
test.badwords.df<-as.data.frame(as.matrix(test.badwords))

# How many badwords in each comments
train.sum<-apply(train.badwords.df,1,sum)
test.sum<-apply(test.badwords.df,1,sum)
length(train.sum)
length(test.sum)
# hist(train.sum)
# hist(test.sum)
head(train.sum)
head(test.sum)

train.insult$n_badwords<-train.sum
test.insult$n_badwords<-test.sum




# The length of the sentence
train.insult$n_words<-sapply(train.insult$Comment,function(x) length(unlist(strsplit(x,"\\s+")))-1)
test.insult$n_words<-sapply(test.insult$Comment,function(x) length(unlist(strsplit(x,"\\s+")))-1)

# Whether "you're" and badwords appear in the same sentence
train.insult$youare_badwords<-mapply(function(youare, n_badwords) {ifelse(youare*n_badwords!=0,1,0)},train.insult$youare,train.insult$n_badwords)
test.insult$youare_badwords<-mapply(function(youare, n_badwords) {ifelse(youare*n_badwords!=0,1,0)},test.insult$youare,test.insult$n_badwords)

###
names(train.insult)
names(test.insult)

for (i in c(6:14,17))
{
    train.insult[,1]<-as.factor(train.insult[,1])
    train.insult[,i]<-as.factor(train.insult[,i])
    test.insult[,i-1]<-as.factor(test.insult[,i-1])
}

for (i in c(4,5,15,16))
{
    train.insult[,i]<-as.numeric(train.insult[,i])
    test.insult[,i-1]<-as.numeric(test.insult[,i-1])
    
}



###### RandomForest Model ######
require(randomForest)


haha<-cbind(train.insult,train.feature)
haha.test<-cbind(test.insult,test.feature)
dim(haha)

haha<-haha[,c(-2,-3,-4,-5,-6)]  # original 3947, na.omit 3229
(ind.else<-which(names(haha)=="else"))
names(haha)[ind.else]<-"else_name"
(ind.for<-which(names(haha)=="for"))
names(haha)[ind.for]<-"for_name"
(ind.next<-which(names(haha)=="next"))
names(haha)[ind.next]<-"next_name"
(ind.while<-which(names(haha)=="break"))
names(haha)[ind.while]<-"break_name"

haha.test<-haha.test[,c(-1,-2,-3,-4,-5)]  # original 3947, na.omit 3229
(ind.else<-which(names(haha.test)=="else"))
names(haha.test)[ind.else]<-"else_name"
(ind.for<-which(names(haha.test)=="for"))
names(haha.test)[ind.for]<-"for_name"
(ind.next<-which(names(haha.test)=="next"))
names(haha.test)[ind.next]<-"next_name"
(ind.while<-which(names(haha.test)=="break"))
names(haha.test)[ind.while]<-"break_name"






rf<-randomForest(Insult~.,data=haha)
rf # 16.47%
result<-as.numeric(as.character(predict(rf,newdata=haha.test)))
write.csv(result,"result.csv",row.names=FALSE)


# cross validation
# rf.cv<-rfcv(haha[,-1],haha[,1])


###### SVM Model ######
install.packages("e1071")
require(e1071)
svm_model<-svm(Insult~.,data=haha,scale=TRUE)

svm_model_tune<-tune.svm(Insult~.,data=haha,gamma=10^(-3:-1),cost=10^(0:3))
summary(svm_model_tune)











# check.train<-cbind(as.numeric(as.character(fitted(svm))),as.numeric(as.character(train.insult[,1])))
# diff.train<-check.train[,2]-check.train[,1]
# (error.train<-sum(abs(diff.train))/nrow(train.insult))
# confusion<-table(check.train[,1],check.train[,2])





# One characteristic that distinguished the more successful algorithms was the ability to detect from context whether a word was being used as an intensifier rather than as an insult.

# The winning algorithm was developed by Vivek Sharma, currently ranked as the second-best data scientist on Kaggle. His approach involved using support vector classification, a high-dimensional modeling technique that enabled him to separate insults from non-insults based on many different types of features within a sentence, such as vocabulary, tone, grammar, and more.







# badwords
badwords<-read.table("badwords.txt",header=FALSE,sep="\t",stringsAsFactors=FALSE)
class(badwords)
dim(badwords)
badwords<-apply(badwords,1,tolower)
length(badwords)
write.csv(badwords,"badwords.csv",row.names=FALSE)

